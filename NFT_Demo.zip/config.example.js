export const nftmarketaddress = ""
export const nftaddress = ""